(function ($) {
    'use strict';

    function renumberRows() {
        $('#tft-video-rows .tft-video-row').each(function (index) {
            $(this).find('[name]').each(function () {
                this.name = this.name.replace(/tft_featured_videos\[[^\]]+\]/, 'tft_featured_videos[' + index + ']');
            });
        });
    }

    function openMediaFrame(row, kind) {
        const isVideo = kind === 'video';
        const frame = wp.media({
            title: isVideo ? 'Select or upload a video' : 'Select a poster image',
            button: { text: isVideo ? 'Use this video' : 'Use this image' },
            library: { type: isVideo ? 'video' : 'image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            row.find(isVideo ? '.tft-video-id' : '.tft-poster-id').val(attachment.id);
            row.find(isVideo ? '.tft-video-name' : '.tft-poster-name').text(attachment.filename);
        });

        frame.open();
    }

    $('#tft-add-video').on('click', function () {
        const template = wp.template('tft-video-row');
        $('#tft-video-rows').append(template({ index: $('#tft-video-rows .tft-video-row').length }));
    });

    $('#tft-video-rows')
        .on('click', '.tft-select-video', function () {
            openMediaFrame($(this).closest('.tft-video-row'), 'video');
        })
        .on('click', '.tft-select-poster', function () {
            openMediaFrame($(this).closest('.tft-video-row'), 'poster');
        })
        .on('click', '.tft-remove-video', function () {
            $(this).closest('.tft-video-row').remove();
            renumberRows();
        })
        .on('click', '.tft-move-up', function () {
            const row = $(this).closest('.tft-video-row');
            row.prev('.tft-video-row').before(row);
            renumberRows();
        })
        .on('click', '.tft-move-down', function () {
            const row = $(this).closest('.tft-video-row');
            row.next('.tft-video-row').after(row);
            renumberRows();
        });
}(jQuery));

