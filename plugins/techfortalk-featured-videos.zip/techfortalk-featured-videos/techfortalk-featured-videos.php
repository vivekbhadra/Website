<?php
/**
 * Plugin Name: Tech For Talk Featured Videos
 * Description: Manage featured homepage videos through the WordPress dashboard and display them with a shortcode.
 * Version: 1.0.0
 * Author: Tech For Talk
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class TFT_Featured_Videos {
    private const OPTION_NAME = 'tft_featured_videos';
    private const PAGE_SLUG   = 'tft-featured-videos';

    public static function init(): void {
        add_action( 'admin_menu', array( self::class, 'add_admin_page' ) );
        add_action( 'admin_init', array( self::class, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_admin_assets' ) );
        add_shortcode( 'tft_featured_videos', array( self::class, 'render_shortcode' ) );
    }

    public static function add_admin_page(): void {
        add_menu_page(
            'Featured Videos',
            'Featured Videos',
            'manage_options',
            self::PAGE_SLUG,
            array( self::class, 'render_admin_page' ),
            'dashicons-video-alt3',
            26
        );
    }

    public static function register_settings(): void {
        register_setting(
            'tft_featured_videos_group',
            self::OPTION_NAME,
            array(
                'type'              => 'array',
                'default'           => array(),
                'sanitize_callback' => array( self::class, 'sanitize_videos' ),
            )
        );
    }

    public static function sanitize_videos( $input ): array {
        if ( ! current_user_can( 'manage_options' ) || ! is_array( $input ) ) {
            return array();
        }

        $videos = array();

        foreach ( $input as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $video_id = isset( $item['video_id'] ) ? absint( $item['video_id'] ) : 0;
            $poster_id = isset( $item['poster_id'] ) ? absint( $item['poster_id'] ) : 0;

            if ( 0 === $video_id || 'attachment' !== get_post_type( $video_id ) ) {
                continue;
            }

            $mime_type = (string) get_post_mime_type( $video_id );
            if ( 0 !== strpos( $mime_type, 'video/' ) ) {
                continue;
            }

            if ( $poster_id && ( 'attachment' !== get_post_type( $poster_id ) || 0 !== strpos( (string) get_post_mime_type( $poster_id ), 'image/' ) ) ) {
                $poster_id = 0;
            }

            $videos[] = array(
                'video_id'   => $video_id,
                'poster_id'  => $poster_id,
                'title'      => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '',
                'description'=> isset( $item['description'] ) ? sanitize_textarea_field( $item['description'] ) : '',
            );
        }

        return array_values( $videos );
    }

    public static function enqueue_admin_assets( string $hook_suffix ): void {
        if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook_suffix ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_script(
            'tft-featured-videos-admin',
            plugin_dir_url( __FILE__ ) . 'assets/admin.js',
            array( 'jquery' ),
            '1.0.0',
            true
        );
        wp_enqueue_style(
            'tft-featured-videos-admin',
            plugin_dir_url( __FILE__ ) . 'assets/admin.css',
            array(),
            '1.0.0'
        );
    }

    public static function render_admin_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage featured videos.', 'tft-featured-videos' ) );
        }

        $videos = get_option( self::OPTION_NAME, array() );
        if ( ! is_array( $videos ) ) {
            $videos = array();
        }
        ?>
        <div class="wrap tft-videos-admin">
            <h1>Featured Videos</h1>
            <p>Add videos from the WordPress Media Library, provide the text shown beside each video, and arrange their display order.</p>

            <form method="post" action="options.php">
                <?php settings_fields( 'tft_featured_videos_group' ); ?>

                <div id="tft-video-rows">
                    <?php foreach ( $videos as $index => $video ) : ?>
                        <?php self::render_admin_row( (int) $index, $video ); ?>
                    <?php endforeach; ?>
                </div>

                <p>
                    <button type="button" class="button button-secondary" id="tft-add-video">Add video</button>
                </p>

                <?php submit_button( 'Save featured videos' ); ?>
            </form>

            <script type="text/html" id="tmpl-tft-video-row">
                <?php self::render_admin_row( '{{data.index}}', array() ); ?>
            </script>

            <div class="tft-shortcode-help">
                <h2>Homepage shortcode</h2>
                <p>Add a WordPress <strong>Shortcode</strong> block immediately above the book section and enter:</p>
                <code>[tft_featured_videos]</code>
            </div>
        </div>
        <?php
    }

    private static function render_admin_row( $index, array $video ): void {
        $video_id   = isset( $video['video_id'] ) ? absint( $video['video_id'] ) : 0;
        $poster_id  = isset( $video['poster_id'] ) ? absint( $video['poster_id'] ) : 0;
        $title      = isset( $video['title'] ) ? (string) $video['title'] : '';
        $description= isset( $video['description'] ) ? (string) $video['description'] : '';
        $video_name = $video_id ? basename( (string) get_attached_file( $video_id ) ) : 'No video selected';
        $poster_name= $poster_id ? basename( (string) get_attached_file( $poster_id ) ) : 'No poster selected';
        $base_name  = self::OPTION_NAME . '[' . $index . ']';
        ?>
        <div class="tft-video-row">
            <div class="tft-video-row__toolbar">
                <strong>Video</strong>
                <span>
                    <button type="button" class="button tft-move-up" aria-label="Move video up">↑</button>
                    <button type="button" class="button tft-move-down" aria-label="Move video down">↓</button>
                    <button type="button" class="button-link-delete tft-remove-video">Remove</button>
                </span>
            </div>

            <input type="hidden" class="tft-video-id" name="<?php echo esc_attr( $base_name . '[video_id]' ); ?>" value="<?php echo esc_attr( (string) $video_id ); ?>">
            <input type="hidden" class="tft-poster-id" name="<?php echo esc_attr( $base_name . '[poster_id]' ); ?>" value="<?php echo esc_attr( (string) $poster_id ); ?>">

            <div class="tft-media-field">
                <button type="button" class="button tft-select-video">Select or upload video</button>
                <span class="tft-video-name"><?php echo esc_html( $video_name ); ?></span>
            </div>

            <div class="tft-media-field">
                <button type="button" class="button tft-select-poster">Select poster image</button>
                <span class="tft-poster-name"><?php echo esc_html( $poster_name ); ?></span>
            </div>

            <label>
                <span>Title</span>
                <input type="text" class="regular-text" name="<?php echo esc_attr( $base_name . '[title]' ); ?>" value="<?php echo esc_attr( $title ); ?>">
            </label>

            <label>
                <span>Description</span>
                <textarea rows="3" class="large-text" name="<?php echo esc_attr( $base_name . '[description]' ); ?>"><?php echo esc_textarea( $description ); ?></textarea>
            </label>
        </div>
        <?php
    }

    public static function render_shortcode(): string {
        $videos = get_option( self::OPTION_NAME, array() );
        if ( ! is_array( $videos ) || array() === $videos ) {
            return '';
        }

        wp_enqueue_style(
            'tft-featured-videos',
            plugin_dir_url( __FILE__ ) . 'assets/featured-videos.css',
            array(),
            '1.0.0'
        );

        ob_start();
        ?>
        <section class="tft-managed-videos" aria-labelledby="tft-managed-videos-title">
            <div class="tft-managed-videos__header">
                <h2 id="tft-managed-videos-title">Featured videos</h2>
                <p>Short videos covering C++, embedded systems, Linux, cloud engineering, and current projects.</p>
            </div>

            <div class="tft-managed-videos__list">
                <?php foreach ( $videos as $video ) : ?>
                    <?php
                    $video_id  = isset( $video['video_id'] ) ? absint( $video['video_id'] ) : 0;
                    $video_url = $video_id ? wp_get_attachment_url( $video_id ) : false;
                    if ( ! $video_url ) {
                        continue;
                    }
                    $mime_type = (string) get_post_mime_type( $video_id );
                    $poster_id = isset( $video['poster_id'] ) ? absint( $video['poster_id'] ) : 0;
                    $poster_url= $poster_id ? wp_get_attachment_image_url( $poster_id, 'large' ) : false;
                    $title     = isset( $video['title'] ) ? (string) $video['title'] : '';
                    $description = isset( $video['description'] ) ? (string) $video['description'] : '';
                    ?>
                    <article class="tft-managed-video">
                        <video controls playsinline preload="metadata"<?php echo $poster_url ? ' poster="' . esc_url( $poster_url ) . '"' : ''; ?>>
                            <source src="<?php echo esc_url( $video_url ); ?>" type="<?php echo esc_attr( $mime_type ); ?>">
                            Your browser does not support embedded video.
                        </video>
                        <div class="tft-managed-video__copy">
                            <?php if ( '' !== $title ) : ?>
                                <h3><?php echo esc_html( $title ); ?></h3>
                            <?php endif; ?>
                            <?php if ( '' !== $description ) : ?>
                                <p><?php echo nl2br( esc_html( $description ) ); ?></p>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
        return (string) ob_get_clean();
    }
}

TFT_Featured_Videos::init();
