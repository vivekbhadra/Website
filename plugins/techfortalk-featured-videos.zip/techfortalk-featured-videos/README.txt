Tech For Talk Featured Videos
=============================

Installation
------------

1. In WordPress, open Plugins > Add New Plugin > Upload Plugin.
2. Select techfortalk-featured-videos.zip.
3. Select Install Now, then Activate Plugin.

One-time homepage setup
-----------------------

1. Edit the homepage.
2. Remove the temporary hard-coded Featured videos HTML section.
3. Insert a Shortcode block immediately above the existing book section.
4. Enter this shortcode:

   [tft_featured_videos]

5. Update the page.

Managing videos
---------------

1. Open Featured Videos in the WordPress dashboard.
2. Select Add video.
3. Select or upload an MP4 through the Media Library.
4. Optionally select a poster image.
5. Enter the title and description.
6. Use the arrow buttons to change the order.
7. Select Save featured videos.

Removing a video from the list does not delete its file from the Media Library.

